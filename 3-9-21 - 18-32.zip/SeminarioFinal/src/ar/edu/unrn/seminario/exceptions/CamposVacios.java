package ar.edu.unrn.seminario.exceptions;

public class CamposVacios extends Exception{

	public CamposVacios (String mensaje) {
		super(mensaje);
	}
}
