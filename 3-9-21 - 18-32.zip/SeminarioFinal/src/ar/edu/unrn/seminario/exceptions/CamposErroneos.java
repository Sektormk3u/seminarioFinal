package ar.edu.unrn.seminario.exceptions;

public class CamposErroneos extends Exception{

	public CamposErroneos (String mensaje) {
		super(mensaje);
	}
	
}
