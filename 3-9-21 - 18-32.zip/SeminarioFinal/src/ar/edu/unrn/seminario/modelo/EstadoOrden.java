package ar.edu.unrn.seminario.modelo;

public class EstadoOrden {

	private String descripcion;
	
	public EstadoOrden(String descripcion) {
		this.descripcion=descripcion;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
