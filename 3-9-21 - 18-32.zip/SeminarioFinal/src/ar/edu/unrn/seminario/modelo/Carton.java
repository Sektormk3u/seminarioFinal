package ar.edu.unrn.seminario.modelo;

public class Carton extends Residuo {

}
