package ar.edu.unrn.seminario.modelo;

public class Papel extends Residuo {

}
