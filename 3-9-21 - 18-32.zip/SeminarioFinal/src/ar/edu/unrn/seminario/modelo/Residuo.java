package ar.edu.unrn.seminario.modelo;

public abstract class Residuo {

	private Integer puntaje;
	
}
