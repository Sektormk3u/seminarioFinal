package ar.edu.unrn.seminario.modelo;

public class Campa�a {

	private Catalogo catalogo;

	public Campa�a(Catalogo catalogo) {
		this.catalogo = catalogo;
	}
}
