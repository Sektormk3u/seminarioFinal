package ar.edu.unrn.seminario.modelo;

import java.sql.Date;

public class PedidoRetiro {

	private Date fecha;
	private Boolean cargaPesada;
	private String observacion;
	
	
	//Ver que recibe orden de retiro
	public Object ordenRetiro(Object objeto) {
		
		return objeto;
	}
	
}
