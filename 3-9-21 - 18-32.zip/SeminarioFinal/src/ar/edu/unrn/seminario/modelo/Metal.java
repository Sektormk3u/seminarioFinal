package ar.edu.unrn.seminario.modelo;

public class Metal extends Residuo {

}
