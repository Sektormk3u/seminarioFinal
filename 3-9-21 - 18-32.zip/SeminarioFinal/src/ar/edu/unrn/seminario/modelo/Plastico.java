package ar.edu.unrn.seminario.modelo;

public class Plastico extends Residuo {

}
