package ar.edu.unrn.seminario.modelo;

public class Beneficio {

	private int codigo;
	private String descripcion;
	private int costoBeneficio;

	public Beneficio(int codigo, String descripcion, int costoBeneficio) {
		this.codigo = codigo;
		this.descripcion = descripcion;
		this.costoBeneficio = costoBeneficio;
	}
}
