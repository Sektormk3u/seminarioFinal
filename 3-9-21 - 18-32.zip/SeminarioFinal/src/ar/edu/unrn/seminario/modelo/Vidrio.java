package ar.edu.unrn.seminario.modelo;

public class Vidrio extends Residuo {

}
