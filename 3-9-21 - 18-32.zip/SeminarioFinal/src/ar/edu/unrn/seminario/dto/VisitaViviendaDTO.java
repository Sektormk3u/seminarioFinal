package ar.edu.unrn.seminario.dto;

public class VisitaViviendaDTO {

}
