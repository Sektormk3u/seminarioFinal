package ar.edu.unrn.seminario.dto;

public class Campa�aDTO {

}
